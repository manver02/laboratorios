<?php
include('class_lib.php');
$diam = $_POST['diam'];
$altu = $_POST['altu'];
$cil = new Cilindro($diam,$altu);
$volumen=$cil->calc_volumen();
$area=$cil->calc_area();
echo "<br/> El volumen del cilindro es de ". $volumen . " metros cúbicos";
echo "<br/> El área del cilindro es de ". $area . " metros cuadrados";
?>