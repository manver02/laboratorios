<html lang="es">
    <head>
        <title>Laboratorio 10.1</title>
        <link rel="stylesheet" type="text/css" href="css/estilo.css">
    </head>
    <body>
    <?php

    require_once("class/votos.php");

    if(array_key_exists('enviar', $_POST))
    {
        print ("<h1>Encuesta. Voto registrado</h1>\n");

        $obj_votos = new votos();
        $result_votos = $obj_votos->listar_votos();

        foreach ($result_votos as $result_voto){
            $votos1=$result_voto['votos1'];
            $votos2=$result_voto['votos2'];
        }

        $voto = $_REQUEST['voto'];
        if ($voto == "si")
        $votos1 = $votos1 +1;
        elseif ($voto == "no")
        $votos2 = $votos2 +1;

        $obj_votos = new votos();
        $result = $obj_votos->actualizar_votos($votos1, $votos2);

        if($result){
            print ("<P>Su voto ha sido registrado. Gracias por participar</P>\n");
            print ("<A href='lab102.php'>Ver resultados</A>\n");
        }
        else {
            print ("<A> href='lab101.php'>Error al actualizar su voto</A>\n");
        }
    }
    else
    {
    ?>

    <H1>Encuesta</H1>

    <P>¿Cree ud. que el precio de la vivienda seguirá subiendo al ritmo actual?</P>

    <form action="lab101.php" method="POST">
        <input type="RADIO" name="voto" value="si" CHECKED>Si<BR>
        <input type="RADIO" name="voto" value="no">No<BR><BR>
        <input type="SUBMIT" name="enviar" value="votar">
    </form>

    <A href="lab102.php">Ver resultados</A>

    <?php
    }
    ?>
    
    </body>
</html>