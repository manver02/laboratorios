<?php

$Factorial= $_POST["Factorial"];

echo 'El factorial del numero !'.$Factorial. ' es: '. obtener_factorial($Factorial);
 
function obtener_factorial($mi_factorial)
{
   if($mi_factorial==1 or $mi_factorial==0)
      return 1;
   else
      return $mi_factorial * obtener_factorial($mi_factorial-1);
}
 
?>