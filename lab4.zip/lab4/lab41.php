<?php

$entrada = $_POST['Porcentaje'];
$feliz = 'feliz.png';
$medio = 'medio.png';
$sad = 'sad.png';

if ($entrada >= 80 and $entrada <=100) {
    echo '<img src=" ' .$feliz . '">';
}
if ($entrada >= 50 and $entrada < 80) {
    echo '<img src=" ' .$medio . '">';
}
if ($entrada <50) {
    echo '<img src=" ' .$sad . '">';
}
if ($entrada >100) {
    echo "El valor ingresado excede la escala de porcentaje esperado";
}
?>