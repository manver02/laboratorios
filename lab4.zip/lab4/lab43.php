<?php

$valoresRandom = array();

$valorRandomPrimero = mt_rand(1,50);

array_push($valoresRandom, $valorRandomPrimero);

$x = 1;

while ($x <= 20) {
    $siguienteValorRadom = mt_rand(1, 50);
    if(in_array($siguienteValorRadom, $valoresRandom)){
       
        continue;
    }else{
         array_push($valoresRandom, $siguienteValorRadom) ;
         echo $valoresRandom[$x] . ' , ';
    $x++;
    }
}
$maximo=max (  $valoresRandom ) ;
$indic = array_search($maximo,$valoresRandom,FALSE);
 echo '<br><br><H1> El elemento mayor en el arreglo es = '.$maximo .'<BR> y su posición es = '. $indic ;
?>