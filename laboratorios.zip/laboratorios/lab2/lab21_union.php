<?php include ("lab21_header.php"); ?>
<p>
    Hola, este es el contenido.
</p>
<?php include ("lab21_footer.php"); ?>