<html>
    <head>
        <title>Laboratorio 2.3</title>
    </head>
        <body>
            <center>
                <?php
                print ("<UL>\n");
                $i=1;
                while ($i<=5)
                {
                    print ("<LI>Elemento $i</LI>\n");
                    $i++;
                }
                print ("</UL>\n");
                ?>
                </center>
            </body>
            </html>