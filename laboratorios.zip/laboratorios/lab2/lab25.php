<html>
    <head>
        <title>Laboratorio 2.5</title>
</head>
<body>
    <?php
    $figuras = array('cuadrado', 'triángulo', 'círculo');
    $figuras[1] = 'rectángulo';
    mostrar_figuras($figuras,"asignación de rectángulo");

    array_push($figuras, 'hexágono');
    mostrar_figuras($figuras,"adición de hexágono al final");

    array_unshift($figuras, 'hexágono');
    mostrar_figuras($figuras,"adición de hexágono al inicio");

    array_pop($figuras);
    mostrar_figuras($figuras,"eliminación del último");

    array_shift($figuras);
    mostrar_figuras($figuras,"eliminación del primero");

    function mostrar_figuras($figuras, $mensaje){
        echo "<br>Arreglo después de $mensaje <br>";
        foreach ($figuras as $figura){
            echo "$figura <br>";
        }
    }
    ?> </body>
    </html>