<?php
require("noexiste.php");
echo ("Hola. El script siguió!");
?>