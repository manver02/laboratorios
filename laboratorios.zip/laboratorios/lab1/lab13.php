<html>
<head>
    <title>Laboratorio 1.3</title>
</head>
<body>
<center>
<?php
echo phpinfo();
?>
</center>
</body>
</html>