<html>
<head>
    <title>Laboratorio 1.2</title>
</head>
<body>
<?php
$n1 = 1;
$n2 = 2;
$suma = $n1+$n2;
echo "suma = ".$suma. "<br>";
echo "$n1+$n2";
?>
</body>
</html>