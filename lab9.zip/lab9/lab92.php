<HTML LANG="es">
    <head>
        <title>Laboratorio 9.1</title>
        <link rel="stylesheet" type="text/css" href="css/estilo.css">
    </head>
    <body>
        <H1>Consulta de noticias</H1>

        <form name="FormFiltro" method="post" action="lab92.php">
            <br/>
            Filtrar por: <SELECT name="campos">
                <OPTION value="texto" SELECTED>Descripcion
                <OPTION value="titulo">Titulo
                <OPTION value="categoria">Categoria
            </SELECT>
            con el valor
            <input type="text" name="valor">
            <input name="ConsultarFiltro" value="Filtrar Datos" type="submit" />
            <input name="ConsultarTodos" value="Ver todos" type="submit" />
        </form>
    <?php
    require_once("class/noticias.php");

    $obj_noticia = new  noticia();
    $noticias = $obj_noticia->consultar_noticias();
    
    if (array_key_exists('ConsultarTodos', $_POST)){
        $obj_noticia = new noticia();
        $noticias_new = $obj_noticia->consultar_noticias();
    }
    if (array_key_exists('ConsultarFiltro', $_POST)){
        $obj_noticia = new noticia();
        $noticias = $obj_noticia->consultar_noticias_filtro($_REQUEST['campos'], $_REQUEST['valor']);
    }

    $nfilas=count($noticias);

    if ($nfilas>0){
        print ("<table>\n");
        print ("<tr>\n");
        print ("<th>Titulo</th>\n");
        print ("<th>texto</th>\n");
        print ("<th>Categorias</th>\n");
        print ("<th>Fecha</th>\n");
        print ("<th>Imagen</th>\n");
        print ("</tr>\n");

        foreach ($noticias as $resultado){
            print ("<tr>\n");
            print ("<td>".$resultado['titulo'] . "</td>\n");
            print ("<td>".$resultado['texto'] . "</td>\n");
            print ("<td>".$resultado['categoria'] . "</td>\n");
            print ("<td>". date("j/n/Y",strtotime($resultado['fecha']))."</td>\n");

            if ($resultado['imagen'] != ""){
                print ("<td><A target='_blank' href='img/" . $resultado['imagen'] ."'><img border='0' src='img/iconotexto.gif'></A></td>\n");
            }
            else{
                print ("<td>&nbsp;</td>\n");
            }
            print ("</tr>\n");
        }
        print ("</table>\n");
    }
    else{
        print ("No hay noticias disponibles");
    }
    ?>
    </body>
    </html>