<footer>
    
    <br><br>
    <a href="index.php" class="a_foot"><input type="button" value="Volver"></a>
</footer>
</body>
</html>