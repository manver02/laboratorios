<?php
$formatos_permitidos =  array('jpg', 'jpeg', 'gif', 'png');
$peso = $_FILES['nombre_archivo_cliente']['size'];
$nombreDirectorio = "archivos/";
$nombrearchivo = $_FILES['nombre_archivo_cliente']['name'];
$extension = pathinfo($nombrearchivo, PATHINFO_EXTENSION);
$nombreCompleto = $nombreDirectorio . $nombrearchivo;
if (is_uploaded_file ($_FILES['nombre_archivo_cliente']['tmp_name']) && in_array($extension, $formatos_permitidos))
{
if($peso <= 1000000){
 if (is_file($nombreCompleto))
 {
 $idUnico = time();
 $nombrearchivo = $idUnico . "-" . $nombrearchivo;
echo "Archivo repetido, se cambiara el nombre a $nombrearchivo 
<br><br>";
 }
 move_uploaded_file ($_FILES['nombre_archivo_cliente']['tmp_name'], $nombreDirectorio . $nombrearchivo);
 
 echo "El archivo se ha subido satisfactoriamente al directorio 
$nombreDirectorio <br>";
}
else
echo "Error, el archivo debe pesar menos a 1MB <br>";
}
else
echo "Error, formato no permitido <br>"; 
echo "No se ha podido subir el archivo <br>";
?>