<?php
    session_start ();
?>
<HTML LANG="es">
    <head>
        <title>Laboratorio 14.3</title>
        <link rel="stylesheet" type="text/css" href="css/estilo.css">
    </head>
    <body>
        <H1>Consulta de noticias</H1>

        <?php
    if (isset($_SESSION["usuario_valido"]))
    {
        print ("<p>[<a href='login.php'>Menú Principal</a>]</p>");
    }
    else
    {
        print ("<br><br>\n");
        print ("<p align='center'>Acceso no autorizado</p>\n");
        print ("<p align='center'>[<a href='login.php' target='_top'>Conectar</a>]</p>\n");
    }
    ?>

    <?php
    require_once("class/noticias.php");

    $obj_noticia = new  noticia();
    $noticias = $obj_noticia->consultar_noticias();

    $nfilas=count($noticias);

    if ($nfilas>0){
        print ("<table>\n");
        print ("<tr>\n");
        print ("<th>Titulo</th>\n");
        print ("<th>texto</th>\n");
        print ("<th>Categorias</th>\n");
        print ("<th>Fecha</th>\n");
        print ("<th>Imagen</th>\n");
        print ("</tr>\n");

        foreach ($noticias as $resultado){
            print ("<tr>\n");
            print ("<td>".$resultado['titulo'] . "</td>\n");
            print ("<td>".$resultado['texto'] . "</td>\n");
            print ("<td>".$resultado['categoria'] . "</td>\n");
            print ("<td>". date("j/n/Y",strtotime($resultado['fecha']))."</td>\n");

            if ($resultado['imagen'] != ""){
                print ("<td><A target='_blank' href='img/" . $resultado['imagen'] ."'><img border='0' src='img/iconotexto.gif'></A></td>\n");
            }
            else{
                print ("<td>&nbsp;</td>\n");
            }
            print ("</tr>\n");
        }
        print ("</table>\n");
    }
    else{
        print ("No hay noticias disponibles");
    }
    ?>
    </body>
    </html>